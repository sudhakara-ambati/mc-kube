package com.mckube.javaplugin;

// The constants are replaced before compilation
public class BuildConstants {

    public static final String VERSION = "${version}";
}
