package com.mckube.javaplugin.services;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Optional;

public class BroadcastService {
    // class for broadcasting messages to all players on the proxy

    private final ProxyServer server;
    private final Logger logger;

    public BroadcastService(ProxyServer server, Logger logger) {
        this.server = server;
        this.logger = logger;
    }

    public void broadcastMessage(String message) {
        // add the word broadcast before
        Component component = Component.text("[Broadcast] ", NamedTextColor.GREEN)
                .append(Component.text(message, NamedTextColor.GOLD)); // GOLD is orange-ish, or use ORANGE

        Collection<Player> players = server.getAllPlayers();
        if (players.isEmpty()) {
            logger.info("No players online to broadcast to");
            return;
        }

        players.forEach(player -> player.sendMessage(component));
        logger.info("Broadcasted message to {} players: {}", players.size(), message);
    }

    public void broadcastMessageToServer(String serverName, String message) {
        Component component = Component.text("[Broadcast] ", NamedTextColor.GREEN)
                .append(Component.text(message, NamedTextColor.GOLD)); // GOLD is orange-ish, or use ORANGE

        Optional<RegisteredServer> serverOptional = server.getServer(serverName);
        if (serverOptional.isEmpty()) {
            logger.warn("Server '{}' not found", serverName);
            return;
        }

        RegisteredServer targetServer = serverOptional.get();
        Collection<Player> playersOnServer = targetServer.getPlayersConnected();

        if (playersOnServer.isEmpty()) {
            logger.info("No players on server '{}' to broadcast to", serverName);
            return;
        }

        playersOnServer.forEach(player -> player.sendMessage(component));
        logger.info("Broadcasted message to {} players on server '{}': {}",
                playersOnServer.size(), serverName, message);
    }

}
