package com.mckube.javaplugin.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.velocitypowered.api.proxy.ProxyServer;
import org.slf4j.Logger;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import java.io.FileReader;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class MetricsService {

    private final ProxyServer server;
    private final Logger logger;
    private final Map<String, Integer> jmxPortMapping;

    public MetricsService(ProxyServer server, Logger logger, Path jmxConfigFile) {
        this.server = server;
        this.logger = logger;

        Map<String, Integer> tempMapping = Collections.emptyMap();
        try {
            if (Files.exists(jmxConfigFile)) {
                try (FileReader reader = new FileReader(jmxConfigFile.toFile())) {
                    tempMapping = new Gson().fromJson(reader,
                            new TypeToken<Map<String, Integer>>() {}.getType());
                    logger.info("Loaded JMX config for {} servers", tempMapping.size());
                }
            } else {
                logger.warn("JMX config file not found at {}", jmxConfigFile);
            }
        } catch (Exception e) {
            logger.error("Failed to read JMX config file: {}", e.getMessage());
        }
        this.jmxPortMapping = tempMapping;
    }

    public Map<String, Object> fetchMetrics(String serverName) {
        Map<String, Object> metrics = new HashMap<>();
        try {
            Integer port = getPortForServer(serverName);
            if (port == null) {
                logger.warn("No JMX port found for server '{}'", serverName);
                metrics.put("success", false);
                metrics.put("message", "Unknown server in JMX config");
                return metrics;
            }

            String host = getServerHostFromVelocity(serverName);
            if (host == null) {
                logger.warn("Server '{}' not found in velocity.toml", serverName);
                metrics.put("success", false);
                metrics.put("message", "Server host not found in velocity.toml");
                return metrics;
            }

            String url = String.format("service:jmx:rmi:///jndi/rmi://%s:%d/jmxrmi", host, port);
            JMXServiceURL jmxUrl = new JMXServiceURL(url);

            try (JMXConnector connector = JMXConnectorFactory.connect(jmxUrl)) {
                MBeanServerConnection mbsc = connector.getMBeanServerConnection();

                MemoryMXBean memoryBean = java.lang.management.ManagementFactory.newPlatformMXBeanProxy(
                        mbsc, "java.lang:type=Memory", MemoryMXBean.class);
                MemoryUsage heap = memoryBean.getHeapMemoryUsage();
                MemoryUsage nonHeap = memoryBean.getNonHeapMemoryUsage();
                metrics.put("heapUsedGB", roundToTwoDecimals(heap.getUsed() / 1_073_741_824.0));
                metrics.put("heapMaxGB", roundToTwoDecimals(heap.getMax() / 1_073_741_824.0));
                metrics.put("nonHeapUsedGB", roundToTwoDecimals(nonHeap.getUsed() / 1_073_741_824.0));
                metrics.put("nonHeapMaxGB", roundToTwoDecimals(nonHeap.getMax() / 1_073_741_824.0));

                ObjectName osBeanName = new ObjectName("java.lang:type=OperatingSystem");
                Double processCpuLoad = (Double) mbsc.getAttribute(osBeanName, "ProcessCpuLoad");
                Double systemCpuLoad = (Double) mbsc.getAttribute(osBeanName, "SystemCpuLoad");
                metrics.put("processCpuPercent", processCpuLoad != null ? roundToTwoDecimals(processCpuLoad * 100) : null);
                metrics.put("systemCpuPercent", systemCpuLoad != null ? roundToTwoDecimals(systemCpuLoad * 100) : null);

                ObjectName threadBean = new ObjectName("java.lang:type=Threading");
                Integer threadCount = (Integer) mbsc.getAttribute(threadBean, "ThreadCount");
                Integer peakThreadCount = (Integer) mbsc.getAttribute(threadBean, "PeakThreadCount");
                metrics.put("threadCount", threadCount);
                metrics.put("peakThreadCount", peakThreadCount);

                List<String> gcNames = List.of("G1 Young Generation", "G1 Old Generation"); // adjust for your GC
                Map<String, Map<String, Object>> gcStats = new HashMap<>();
                for (String gcName : gcNames) {
                    ObjectName gcBean = new ObjectName("java.lang:type=GarbageCollector,name=" + gcName);
                    Map<String, Object> gcMap = new HashMap<>();
                    gcMap.put("collections", mbsc.getAttribute(gcBean, "CollectionCount"));
                    gcMap.put("timeMs", mbsc.getAttribute(gcBean, "CollectionTime"));
                    gcStats.put(gcName, gcMap);
                }
                metrics.put("garbageCollectors", gcStats);

                // System load
                Double systemLoad = (Double) mbsc.getAttribute(osBeanName, "SystemLoadAverage");
                Integer processors = (Integer) mbsc.getAttribute(osBeanName, "AvailableProcessors");
                metrics.put("systemLoadPercent", systemLoad != null && processors != null ?
                        roundToTwoDecimals((systemLoad / processors) * 100) : null);

                metrics.put("success", true);
            }

        } catch (Exception e) {
            logger.error("Failed to fetch metrics for server '{}': {}", serverName, e.getMessage());
            metrics.put("success", false);
            metrics.put("message", "Error fetching metrics");
        }

        return metrics;
    }

    private double roundToTwoDecimals(double value) {
        return Math.round(value * 100.0) / 100.0;
    }



    public Integer getPortForServer(String serverName) {
        return jmxPortMapping.get(serverName.toLowerCase());
    }

    private String getServerHostFromVelocity(String serverName) {
        return server.getServer(serverName)
                .map(s -> s.getServerInfo().getAddress().getHostString())
                .orElse(null);
    }
}
