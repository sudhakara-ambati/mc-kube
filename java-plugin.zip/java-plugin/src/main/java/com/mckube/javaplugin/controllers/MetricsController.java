package com.mckube.javaplugin.controllers;

import com.mckube.javaplugin.services.MetricsService;
import io.javalin.Javalin;
import io.javalin.http.Context;
import org.slf4j.Logger;

import java.util.Map;

public class MetricsController {

    private final MetricsService metricsService;
    private final Logger logger;

    public MetricsController(MetricsService metricsService, Logger logger) {
        this.metricsService = metricsService;
        this.logger = logger;
    }

    public void registerRoutes(Javalin app) {
        app.get("/metrics/{server}", this::handleMetrics);
    }

    private void handleMetrics(Context ctx) {
        String serverName = ctx.pathParam("server").toLowerCase();
        Map<String, Object> metrics = metricsService.fetchMetrics(serverName);
        ctx.json(metrics);
    }
}
