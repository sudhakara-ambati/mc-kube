package com.mckube.javaplugin.services;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import org.slf4j.Logger;

import java.util.Optional;

public class TransferService {

    private final ProxyServer server;
    private final Logger logger;

    public TransferService(ProxyServer server, Logger logger) {
        this.server = server;
        this.logger = logger;
    }

    public boolean transferPlayer(String playerName, String serverName) {
        Optional<Player> playerOptional = server.getPlayer(playerName);
        Optional<RegisteredServer> targetServer = server.getServer(serverName);

        if (playerOptional.isEmpty() || targetServer.isEmpty()) {
            return false;
        }

        playerOptional.get().createConnectionRequest(targetServer.get()).fireAndForget();
        logger.info("Transferred {} to {}", playerName, serverName);
        return true;
    }
}
